# Design Document

## Overview

This design addresses the product image display issues in the Montclair Wardrobe Django application. The solution involves fixing the Product model's duplicate image field, correcting template syntax for image rendering, ensuring proper media file configuration, and implementing cloud storage for production persistence.

## Architecture

### Component Diagram

```mermaid
graph TB
    Admin[Admin Interface] --> ProductModel[Product Model]
    ProductModel --> Storage[Storage Backend]
    Storage --> LocalFS[Local Filesystem - Dev]
    Storage --> Cloudinary[Cloudinary - Production]
    ProductModel --> Template[Django Templates]
    Template --> Browser[User Browser]
    Settings[Django Settings] --> Storage
    Settings --> Template
```

### Data Flow

1. **Image Upload Flow**:
   - Admin uploads image via Django admin
   - Product model receives image file
   - Storage backend (local or Cloudinary) stores the file
   - Model saves file reference in database

2. **Image Display Flow**:
   - View queries Product model
   - Template receives product data with image field
   - Template constructs image URL using MEDIA_URL or Cloudinary URL
   - Browser requests and displays image

## Components and Interfaces

### 1. Product Model Fix

**File**: `home/models.py`

**Changes**:
- Remove duplicate `image` field definition (first occurrence at line ~67)
- Keep the second, more complete definition with proper upload_to path
- Ensure single ImageField with path: `upload_to="products/%Y/%m/%d/"`

**Interface**:
```python
class Product(models.Model):
    # ... other fields ...
    image = models.ImageField(
        upload_to="products/%Y/%m/%d/",
        null=True,
        blank=True,
        verbose_name=_("Product Image")
    )
```

### 2. Template Image Rendering

**File**: `home/templates/home/index.html`

**Current Issue**:
```html
<img src="{{ product.image.url|default:'/static/images/default-product.jpg' }}"
```

**Problem**: The `|default` filter doesn't work with `.url` attribute when image is None

**Solution**:
```html
{% if product.image %}
    <img src="{{ product.image.url }}" 
         alt="{{ product.name }}" 
         class="card-img-top" 
         loading="lazy"
         onerror="this.src='/static/images/default-product.jpg'">
{% else %}
    <img src="{% static 'images/default-product.jpg' %}" 
         alt="{{ product.name }}" 
         class="card-img-top" 
         loading="lazy">
{% endif %}
```

**Benefits**:
- Proper conditional rendering
- Fallback via onerror for broken images
- Maintains lazy loading for performance
- Accessible alt text

### 3. Settings Configuration

**File**: `montclair_wardrobe/settings.py`

**Current State**: Already configured correctly
```python
MEDIA_URL = '/media/'
MEDIA_ROOT = os.path.join(BASE_DIR, 'media')
```

**Verification Needed**: Ensure MEDIA_URL is available in template context

**Add to context processors** (if not already present):
```python
TEMPLATES = [
    {
        'OPTIONS': {
            'context_processors': [
                # ... existing processors ...
                'django.template.context_processors.media',  # Add this
            ],
        },
    },
]
```

### 4. URL Configuration

**File**: `montclair_wardrobe/urls.py`

**Current State**: Already configured correctly for development
```python
if settings.DEBUG:
    urlpatterns += static(settings.MEDIA_URL, document_root=settings.MEDIA_ROOT)
```

**Status**: No changes needed

### 5. Cloud Storage Integration (Production)

**Implementation**: Cloudinary integration for Render deployment

**New Dependencies**:
```
cloudinary==1.36.0
django-cloudinary-storage==0.3.0
```

**Settings Configuration**:
```python
# Cloudinary configuration for production
if not DEBUG:
    import cloudinary
    import cloudinary.uploader
    import cloudinary.api
    
    CLOUDINARY_STORAGE = {
        'CLOUD_NAME': os.environ.get('CLOUDINARY_CLOUD_NAME'),
        'API_KEY': os.environ.get('CLOUDINARY_API_KEY'),
        'API_SECRET': os.environ.get('CLOUDINARY_API_SECRET')
    }
    
    DEFAULT_FILE_STORAGE = 'cloudinary_storage.storage.MediaCloudinaryStorage'
```

**Environment Variables** (to be set in Render):
- `CLOUDINARY_CLOUD_NAME`
- `CLOUDINARY_API_KEY`
- `CLOUDINARY_API_SECRET`

**Model Changes**: None required - Django will automatically use the configured storage backend

## Data Models

### Product Model Schema

```python
class Product(models.Model):
    name = CharField(max_length=255)
    description = TextField(blank=True, null=True)
    price = DecimalField(max_digits=10, decimal_places=2)
    seller = ForeignKey(User)
    category = ForeignKey(Category, null=True, blank=True)
    image = ImageField(upload_to="products/%Y/%m/%d/", null=True, blank=True)  # Single field
    status = CharField(max_length=50, choices=STATUS_CHOICES, default="draft")
    stock = PositiveIntegerField(default=0)
    approval_status = CharField(max_length=20, choices=APPROVAL_CHOICES, default="pending")
    # ... other fields ...
```

**Key Points**:
- Single image field definition
- Organized upload path by date
- Nullable for products without images
- Works with both local and cloud storage backends

## Error Handling

### Image Upload Errors

**Scenario**: Invalid file format uploaded
**Handling**: Django's ImageField validation will reject non-image files
**User Feedback**: Admin interface shows validation error

**Scenario**: File too large
**Handling**: Add MAX_UPLOAD_SIZE validation in model clean() method
**User Feedback**: Clear error message about size limit

### Image Display Errors

**Scenario**: Image file missing from storage
**Handling**: Template uses onerror attribute to load default image
**Fallback**: Default placeholder image from static files

**Scenario**: Cloudinary service unavailable
**Handling**: Browser timeout will trigger onerror fallback
**Monitoring**: Log Cloudinary errors for investigation

### Migration Errors

**Scenario**: Duplicate field causes migration conflict
**Handling**: Create migration to remove duplicate field first
**Recovery**: Manual database inspection if needed

## Testing Strategy

### Unit Tests

**Test File**: `home/tests/test_models.py`

```python
def test_product_image_field_exists():
    """Verify Product model has single image field"""
    
def test_product_image_upload():
    """Test image upload and storage"""
    
def test_product_without_image():
    """Verify products can exist without images"""
```

### Integration Tests

**Test File**: `home/tests/test_views.py`

```python
def test_homepage_displays_product_images():
    """Verify images render correctly on homepage"""
    
def test_homepage_handles_missing_images():
    """Verify default image shows when product has no image"""
    
def test_image_url_construction():
    """Verify correct URL generation for images"""
```

### Template Tests

**Test File**: `home/tests/test_templates.py`

```python
def test_image_conditional_rendering():
    """Test if/else logic for image display"""
    
def test_image_fallback_attributes():
    """Verify onerror and alt attributes present"""
```

### Manual Testing Checklist

1. **Development Environment**:
   - [ ] Upload product image via admin
   - [ ] Verify image appears on homepage
   - [ ] Verify image appears on product detail page
   - [ ] Test with product that has no image
   - [ ] Test image deletion and re-upload

2. **Production Environment (Render)**:
   - [ ] Configure Cloudinary credentials
   - [ ] Upload product image via admin
   - [ ] Verify image persists after deployment
   - [ ] Restart application and verify images still load
   - [ ] Test with multiple image uploads

3. **Error Scenarios**:
   - [ ] Upload non-image file (should reject)
   - [ ] Delete image file manually (should show default)
   - [ ] Test with slow network (lazy loading)
   - [ ] Test with Cloudinary credentials removed (should fail gracefully)

## Implementation Phases

### Phase 1: Model Fix (Critical)
1. Remove duplicate image field from Product model
2. Create and run migration
3. Verify no data loss

### Phase 2: Template Fix (Critical)
1. Update image rendering logic in all templates
2. Add default image to static files
3. Test image display

### Phase 3: Cloud Storage (Production)
1. Install Cloudinary packages
2. Configure settings for production
3. Set environment variables in Render
4. Test image persistence

### Phase 4: Testing & Validation
1. Run automated tests
2. Perform manual testing
3. Deploy to production
4. Monitor for errors

## Rollback Plan

If issues occur after deployment:

1. **Model Migration Issues**: 
   - Revert migration: `python manage.py migrate home <previous_migration>`
   - Restore from database backup if needed

2. **Template Issues**:
   - Revert template changes via git
   - Redeploy previous version

3. **Cloudinary Issues**:
   - Switch back to local storage temporarily
   - Investigate Cloudinary configuration
   - Re-enable after fixing credentials

## Performance Considerations

- **Lazy Loading**: Images use `loading="lazy"` attribute for better page load performance
- **Image Optimization**: Consider adding image compression before upload (future enhancement)
- **CDN**: Cloudinary provides CDN automatically for fast global delivery
- **Caching**: Browser caching enabled for static default images

## Security Considerations

- **File Validation**: Django ImageField validates file types
- **Size Limits**: Implement max file size validation
- **Access Control**: Only authenticated admins can upload images
- **Cloudinary Credentials**: Stored as environment variables, never in code
- **HTTPS**: All image URLs should use HTTPS in production
