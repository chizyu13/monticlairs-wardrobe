# Requirements Document

## Introduction

This document outlines the requirements for the Montclair Wardrobe e-commerce system, a comprehensive online shopping platform for fashion and wardrobe products. The system enables customers to browse products, manage shopping carts, place orders, and track deliveries across Lusaka, Zambia.

## Glossary

- **E-commerce System**: The complete web application for Montclair Wardrobe online store
- **User Account**: A registered customer profile with authentication credentials
- **Shopping Cart**: A temporary collection of products selected by a user for purchase
- **Product**: An item available for purchase in the store
- **Product Variation**: Different options of a product such as size, color, or style
- **Category**: A classification group for organizing products
- **Order**: A confirmed purchase transaction containing one or more products
- **Delivery Method**: The transportation service used to deliver products to customers
- **Payment Method**: The financial instrument used to complete a purchase
- **Inventory**: The stock quantity available for each product
- **Review**: Customer feedback and rating for a purchased product
- **Order Status**: The current stage of an order in its lifecycle

## Requirements

### Requirement 1: User Account Management

**User Story:** As a customer, I want to create an account and log in to the website, so that I can access personalized features and track my orders.

#### Acceptance Criteria

1. THE E-commerce System SHALL provide a registration form accepting username, email, and password
2. WHEN a user submits valid registration details, THE E-commerce System SHALL create a new User Account
3. THE E-commerce System SHALL validate that email addresses are unique across all User Accounts
4. THE E-commerce System SHALL hash and securely store user passwords
5. WHEN a registered user provides valid credentials, THE E-commerce System SHALL authenticate the user and create a session
6. THE E-commerce System SHALL provide a logout function that terminates the user session
7. THE E-commerce System SHALL provide a password reset mechanism via email verification

### Requirement 2: Contact Details Management

**User Story:** As a registered customer, I want to store my contact details in my profile, so that I don't have to re-enter them for every order.

#### Acceptance Criteria

1. THE E-commerce System SHALL allow users to store their full name in their User Account
2. THE E-commerce System SHALL allow users to store their email address in their User Account
3. THE E-commerce System SHALL allow users to store their phone number in their User Account
4. WHEN a user updates contact details, THE E-commerce System SHALL validate the email format
5. WHEN a user updates contact details, THE E-commerce System SHALL validate the phone number format for Zambian numbers

### Requirement 3: Address Management

**User Story:** As a customer, I want to add multiple delivery addresses to my account and set a default address, so that I can easily select where my orders should be delivered.

#### Acceptance Criteria

1. THE E-commerce System SHALL allow users to add one or more delivery addresses to their User Account
2. WHEN adding an address, THE E-commerce System SHALL accept delivery area, specific neighborhood, street address, and GPS coordinates
3. THE E-commerce System SHALL allow users to designate one address as the default delivery address
4. THE E-commerce System SHALL allow users to edit existing addresses
5. THE E-commerce System SHALL allow users to delete addresses that are not associated with pending orders
6. WHEN a user has a default address set, THE E-commerce System SHALL pre-populate the checkout form with the default address

### Requirement 4: Payment Method Management

**User Story:** As a customer, I want to add multiple payment methods to my account and set a default payment method, so that checkout is faster and more convenient.

#### Acceptance Criteria

1. THE E-commerce System SHALL allow users to add one or more payment methods to their User Account
2. THE E-commerce System SHALL support Cash on Delivery as a payment method
3. THE E-commerce System SHALL support MTN Mobile Money as a payment method
4. THE E-commerce System SHALL support Airtel Money as a payment method
5. THE E-commerce System SHALL allow users to designate one payment method as the default
6. WHEN a user has a default payment method set, THE E-commerce System SHALL pre-select it during checkout
7. THE E-commerce System SHALL allow users to remove payment methods from their account

### Requirement 5: Product Catalog

**User Story:** As a store administrator, I want to manage a large catalog of products, so that customers can browse and purchase our wardrobe items.

#### Acceptance Criteria

1. THE E-commerce System SHALL store product information including name, description, price, and images
2. THE E-commerce System SHALL allow administrators to create new products
3. THE E-commerce System SHALL allow administrators to edit existing product details
4. THE E-commerce System SHALL allow administrators to set product status as active or inactive
5. THE E-commerce System SHALL display only active products to customers
6. THE E-commerce System SHALL support uploading and displaying product images
7. THE E-commerce System SHALL display product price in Zambian Kwacha (ZMW)


### Requirement 6: Product Categories

**User Story:** As a customer, I want products organized into categories, so that I can easily find the type of items I'm looking for.

#### Acceptance Criteria

1. THE E-commerce System SHALL organize products into categories
2. THE E-commerce System SHALL allow each product to belong to one primary category
3. THE E-commerce System SHALL support hierarchical category structures where categories can have parent categories
4. THE E-commerce System SHALL allow administrators to create, edit, and delete categories
5. THE E-commerce System SHALL display category navigation to customers
6. WHEN a customer selects a category, THE E-commerce System SHALL display all products belonging to that category and its subcategories
7. THE E-commerce System SHALL display the number of products in each category

### Requirement 7: Product Variations

**User Story:** As a customer, I want to select different variations of a product such as color or size, so that I can purchase exactly what I need.

#### Acceptance Criteria

1. THE E-commerce System SHALL allow products to have multiple variations
2. THE E-commerce System SHALL support variation types including color, size, and style
3. WHEN a product has variations, THE E-commerce System SHALL display all available options to the customer
4. THE E-commerce System SHALL allow each variation to have different values such as "red", "blue", "black" for color
5. THE E-commerce System SHALL track inventory separately for each product variation
6. WHEN a customer selects a variation, THE E-commerce System SHALL update the product display to reflect the selected variation
7. THE E-commerce System SHALL allow administrators to add, edit, and remove product variations

### Requirement 8: Inventory Management

**User Story:** As a store administrator, I want the system to track the number of each product in stock, so that we don't oversell items and customers know what's available.

#### Acceptance Criteria

1. THE E-commerce System SHALL maintain a stock quantity for each product and product variation
2. THE E-commerce System SHALL display stock availability status to customers (in stock, low stock, out of stock)
3. WHEN a product stock quantity is zero, THE E-commerce System SHALL mark the product as out of stock
4. WHEN a product stock quantity is below 5 units, THE E-commerce System SHALL display a low stock warning
5. WHEN an order is placed, THE E-commerce System SHALL decrease the stock quantity by the ordered amount
6. IF a product is out of stock, THEN THE E-commerce System SHALL prevent customers from adding it to their cart
7. THE E-commerce System SHALL allow administrators to manually adjust stock quantities

### Requirement 9: Shopping Cart

**User Story:** As a visitor or customer, I want to add products to a shopping cart, so that I can review my selections before completing my purchase.

#### Acceptance Criteria

1. THE E-commerce System SHALL allow both logged-in users and guests to add products to a Shopping Cart
2. WHEN a logged-in user adds a product to the cart, THE E-commerce System SHALL persist the cart in the database
3. WHEN a guest user adds a product to the cart, THE E-commerce System SHALL store the cart in the browser session
4. THE E-commerce System SHALL allow users to specify quantity when adding products to the cart
5. THE E-commerce System SHALL allow users to update product quantities in the cart
6. THE E-commerce System SHALL allow users to remove products from the cart
7. THE E-commerce System SHALL display the total price of all items in the cart
8. WHEN a guest user logs in, THE E-commerce System SHALL merge the session cart with the user's saved cart
9. THE E-commerce System SHALL display a cart icon with the number of items in the header

### Requirement 10: Order Payment and Address Details

**User Story:** As a customer, I want to provide my payment details and delivery address during checkout, so that my order can be processed and delivered.

#### Acceptance Criteria

1. THE E-commerce System SHALL require customers to provide a delivery address before completing an order
2. THE E-commerce System SHALL require customers to select a payment method before completing an order
3. THE E-commerce System SHALL validate that all required address fields are completed
4. THE E-commerce System SHALL validate that a GPS location is provided for delivery
5. THE E-commerce System SHALL require a phone number for delivery coordination
6. WHEN a user has saved addresses, THE E-commerce System SHALL allow selection from saved addresses
7. THE E-commerce System SHALL allow users to enter a new address during checkout

### Requirement 11: Delivery Methods

**User Story:** As a customer, I want to choose from different delivery methods with different prices, so that I can select the option that best fits my needs and budget.

#### Acceptance Criteria

1. THE E-commerce System SHALL provide multiple delivery methods based on delivery area
2. THE E-commerce System SHALL offer City Center/CBD delivery at ZMW 30
3. THE E-commerce System SHALL offer Residential Areas delivery at ZMW 50
4. THE E-commerce System SHALL offer Compounds delivery at ZMW 40
5. THE E-commerce System SHALL offer Suburbs delivery at ZMW 60
6. WHEN a customer selects a delivery area, THE E-commerce System SHALL display the corresponding delivery fee
7. THE E-commerce System SHALL add the delivery fee to the order total
8. THE E-commerce System SHALL store the selected delivery method with the order


### Requirement 12: Order Status Tracking

**User Story:** As a customer, I want to track the status of my order from placement to delivery, so that I know when to expect my items.

#### Acceptance Criteria

1. WHEN an order is placed, THE E-commerce System SHALL set the initial order status to "Processing"
2. WHEN an order is dispatched, THE E-commerce System SHALL update the order status to "Delivery in Progress"
3. WHEN an order is completed, THE E-commerce System SHALL update the order status to "Delivered"
4. THE E-commerce System SHALL allow administrators to manually update order status
5. THE E-commerce System SHALL display the current order status to customers in their order history
6. THE E-commerce System SHALL display the order status on the order detail page
7. THE E-commerce System SHALL record the timestamp for each status change

### Requirement 13: Product Reviews

**User Story:** As a customer, I want to leave reviews for products I have purchased, so that I can share my experience and help other customers make informed decisions.

#### Acceptance Criteria

1. THE E-commerce System SHALL allow customers to leave reviews for products they have purchased
2. WHEN submitting a review, THE E-commerce System SHALL require a rating from 1 to 5 stars
3. WHEN submitting a review, THE E-commerce System SHALL require a text comment
4. THE E-commerce System SHALL validate that the comment is between 10 and 500 characters
5. THE E-commerce System SHALL display all approved reviews on the product detail page
6. THE E-commerce System SHALL calculate and display the average rating for each product
7. THE E-commerce System SHALL display the number of reviews for each product
8. THE E-commerce System SHALL allow administrators to moderate and remove inappropriate reviews
9. THE E-commerce System SHALL prevent customers from reviewing products they have not purchased
