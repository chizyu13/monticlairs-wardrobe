# This app doesn't need its own models
# All models are handled by the home app