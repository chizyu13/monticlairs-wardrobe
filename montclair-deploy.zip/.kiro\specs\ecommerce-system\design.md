# Design Document

## Overview

The Montclair Wardrobe e-commerce system is a Django-based web application that provides a complete online shopping platform for fashion and wardrobe products in Lusaka, Zambia. The system follows the Model-View-Template (MVT) architecture pattern and is organized into modular Django apps for separation of concerns.

### Technology Stack

- **Backend Framework**: Django 5.1.7
- **Database**: SQLite3 (development), PostgreSQL recommended for production
- **Frontend**: HTML5, CSS3, JavaScript with Bootstrap 5
- **Payment Integration**: Stripe, MTN Mobile Money, Airtel Money
- **Map Integration**: Leaflet.js for GPS location selection
- **Session Management**: Django database-backed sessions
- **Authentication**: Django built-in authentication system

### Key Design Principles

1. **Modularity**: Separate Django apps for distinct functionality (home, cart, accounts, payment, custom_admin)
2. **Security**: Password hashing, CSRF protection, secure payment handling
3. **Scalability**: Database indexing, optimized queries, session management
4. **User Experience**: Responsive design, real-time cart updates, GPS-based delivery
5. **Localization**: Zambian Kwacha currency, local phone number validation, Lusaka-specific delivery zones

## Architecture

### System Architecture Diagram

```
┌─────────────────────────────────────────────────────────────┐
│                        Client Layer                          │
│  (Web Browser - HTML/CSS/JS + Leaflet.js + Bootstrap)       │
└────────────────────┬────────────────────────────────────────┘
                     │ HTTP/HTTPS
┌────────────────────▼────────────────────────────────────────┐
│                    Django Application                        │
│  ┌──────────────────────────────────────────────────────┐   │
│  │              URL Routing Layer                       │   │
│  │         (montclair_wardrobe/urls.py)                 │   │
│  └──────────────────┬───────────────────────────────────┘   │
│                     │                                        │
│  ┌──────────────────▼───────────────────────────────────┐   │
│  │                 View Layer                           │   │
│  │  ┌──────┐  ┌──────┐  ┌──────┐  ┌──────┐  ┌──────┐  │   │
│  │  │ Home │  │ Cart │  │Accts │  │ Pay  │  │Admin │  │   │
│  │  │ Views│  │ Views│  │Views │  │Views │  │Views │  │   │
│  │  └──────┘  └──────┘  └──────┘  └──────┘  └──────┘  │   │
│  └──────────────────┬───────────────────────────────────┘   │
│                     │                                        │
│  ┌──────────────────▼───────────────────────────────────┐   │
│  │              Business Logic Layer                    │   │
│  │         (Models, Forms, Validators)                  │   │
│  └──────────────────┬───────────────────────────────────┘   │
│                     │                                        │
│  ┌──────────────────▼───────────────────────────────────┐   │
│  │              Data Access Layer                       │   │
│  │            (Django ORM)                              │   │
│  └──────────────────┬───────────────────────────────────┘   │
└────────────────────┬┴───────────────────────────────────────┘
                     │
┌────────────────────▼────────────────────────────────────────┐
│                  Database Layer                              │
│              (SQLite3 / PostgreSQL)                          │
└─────────────────────────────────────────────────────────────┘

┌─────────────────────────────────────────────────────────────┐
│                 External Services                            │
│  ┌──────────┐  ┌──────────┐  ┌──────────┐  ┌──────────┐    │
│  │  Stripe  │  │   MTN    │  │  Airtel  │  │ OpenStreet│   │
│  │   API    │  │  Mobile  │  │  Money   │  │    Map    │   │
│  └──────────┘  └──────────┘  └──────────┘  └──────────┘    │
└─────────────────────────────────────────────────────────────┘
```

### Django App Structure

The system is organized into five main Django applications:

1. **home**: Core product catalog, orders, reviews, and main pages
2. **cart**: Shopping cart and checkout functionality
3. **accounts**: User authentication, profiles, and account management
4. **payment**: Payment processing integration
5. **custom_admin**: Administrative dashboard and management tools

## Components and Interfaces

### 1. User Management Component (accounts app)

**Purpose**: Handle user registration, authentication, and profile management

**Key Classes**:
- `Profile` model: Extends Django User with bio, location, phone, profile picture, and role
- `ProfileForm`: Form for updating user profile information

**Interfaces**:
- `POST /accounts/register/`: User registration
- `POST /accounts/login/`: User authentication
- `GET/POST /accounts/profile/`: View and update profile
- `POST /accounts/logout/`: User logout

**Key Features**:
- Role-based access (client, admin)
- Zambian phone number validation
- Profile picture upload
- One-to-one relationship with Django User model

### 2. Product Catalog Component (home app)

**Purpose**: Manage products, categories, and product display

**Key Classes**:
- `Product` model: Product information with approval workflow
- `Category` model: Hierarchical product categorization
- `ProductForm`: Form for creating/editing products
- `CategoryForm`: Form for managing categories

**Product Model Fields**:
- name, description, price, image
- seller (ForeignKey to User)
- category (ForeignKey to Category)
- stock (inventory quantity)
- status (active, inactive, sold, draft)
- approval_status (pending, approved, rejected)
- approved_by, approved_at (approval tracking)

**Interfaces**:
- `GET /products/`: List all active products
- `GET /products/<id>/`: Product detail page
- `POST /products/create/`: Create new product (sellers)
- `PUT /products/<id>/edit/`: Edit product
- `GET /categories/`: List categories
- `GET /categories/<id>/products/`: Products by category

**Key Features**:
- Product approval workflow
- Stock management with validation
- Category hierarchy support
- Image upload handling
- Seller-specific product management

### 3. Shopping Cart Component (cart app)

**Purpose**: Manage shopping cart items and checkout process

**Key Classes**:
- `Cart` model: Cart items for logged-in users
- `Checkout` model: Checkout information and delivery details

**Cart Model Fields**:
- user (ForeignKey to User)
- product (ForeignKey to Product)
- quantity (positive integer)
- added_at (timestamp)

**Checkout Model Fields**:
- user, location, room_number, phone_number
- gps_location (GPS coordinates)
- payment_method (cash, delivery, mtn, airtel)
- delivery_fee (calculated based on location)
- transaction_id, payment_status
- created_at, updated_at

**Interfaces**:
- `POST /cart/add/`: Add item to cart
- `GET /cart/`: View cart
- `PUT /cart/update/<id>/`: Update cart item quantity
- `DELETE /cart/remove/<id>/`: Remove cart item
- `POST /checkout/`: Process checkout
- `GET /checkout/success/`: Checkout confirmation

**Key Features**:
- Session-based cart for guests
- Database-persisted cart for logged-in users
- Cart merging on login
- GPS location selection via Leaflet.js map
- Dynamic delivery fee calculation
- Zambian phone number validation

### 4. Order Management Component (home app)

**Purpose**: Handle order creation, tracking, and fulfillment

**Key Classes**:
- `Order` model: Individual order records
- `Sale` model: Completed sales tracking

**Order Model Fields**:
- user, product, quantity, total_price
- status (pending, processing, shipped, delivered, cancelled)
- checkout (ForeignKey to Checkout)
- created_at, updated_at

**Interfaces**:
- `GET /orders/`: User order history
- `GET /orders/<id>/`: Order detail
- `PUT /orders/<id>/status/`: Update order status (admin)

**Key Features**:
- Automatic stock reduction on order creation
- Order status lifecycle tracking
- Total price calculation
- Relationship with checkout for delivery details

### 5. Review System Component (home app)

**Purpose**: Enable customer product reviews and ratings

**Key Classes**:
- `Review` model: Product reviews with ratings

**Review Model Fields**:
- product, user, rating (1-5 stars)
- title, comment
- is_verified_purchase (boolean)
- created_at, updated_at

**Interfaces**:
- `POST /products/<id>/review/`: Submit review
- `GET /products/<id>/reviews/`: View product reviews
- `DELETE /reviews/<id>/`: Delete review (admin/owner)

**Key Features**:
- 1-5 star rating system
- Verified purchase badge
- One review per user per product (unique_together constraint)
- Average rating calculation
- Review moderation capability

### 6. Payment Processing Component (payment app)

**Purpose**: Handle payment transactions across multiple payment methods

**Key Classes**:
- `Payment` model: Payment transaction records

**Payment Model Fields**:
- user, method (airtel, mtn, stripe)
- amount, reference (unique transaction ID)
- status (pending, completed, failed)
- created_at

**Supported Payment Methods**:
1. **Cash on Delivery**: No online processing
2. **MTN Mobile Money**: Integration with MTN API
3. **Airtel Money**: Integration with Airtel API
4. **Stripe**: Credit/debit card processing

**Interfaces**:
- `POST /payment/process/`: Initiate payment
- `GET /payment/status/<reference>/`: Check payment status
- `POST /payment/webhook/`: Handle payment provider callbacks

**Key Features**:
- Multi-payment method support
- Unique transaction reference generation
- Payment status tracking
- Webhook handling for async payment confirmation

### 7. Delivery Management Component

**Purpose**: Calculate delivery fees and manage delivery information

**Delivery Zones and Fees**:
- City Center/CBD: ZMW 30
- Residential Areas: ZMW 50
- Compounds: ZMW 40
- Suburbs: ZMW 60

**Key Features**:
- GPS coordinate capture via Leaflet.js
- Area-based delivery fee calculation
- Phone number for delivery coordination
- Street address and neighborhood details


## Data Models

### Entity Relationship Diagram

```
┌─────────────┐
│    User     │
│ (Django)    │
└──────┬──────┘
       │
       │ 1:1
       ▼
┌─────────────┐
│   Profile   │
│  - bio      │
│  - location │
│  - phone    │
│  - picture  │
│  - role     │
└─────────────┘

┌─────────────┐         ┌─────────────┐
│    User     │◄────────┤  Category   │
└──────┬──────┘  creates│  - name     │
       │                 │  - desc     │
       │ 1:N             │  - created  │
       ▼                 └─────────────┘
┌─────────────┐                │
│   Product   │                │ 1:N
│  - name     │◄───────────────┘
│  - desc     │
│  - price    │
│  - image    │
│  - stock    │
│  - status   │
│  - approval │
└──────┬──────┘
       │
       │ 1:N
       ▼
┌─────────────┐         ┌─────────────┐
│   Review    │         │    Cart     │
│  - rating   │         │  - quantity │
│  - title    │         │  - added_at │
│  - comment  │         └──────┬──────┘
│  - verified │                │
└─────────────┘                │ N:1
                               ▼
                        ┌─────────────┐
                        │    User     │
                        └──────┬──────┘
                               │
                               │ 1:N
                               ▼
                        ┌─────────────┐
                        │  Checkout   │
                        │  - location │
                        │  - gps_loc  │
                        │  - phone    │
                        │  - payment  │
                        │  - del_fee  │
                        └──────┬──────┘
                               │
                               │ 1:N
                               ▼
                        ┌─────────────┐
                        │    Order    │
                        │  - quantity │
                        │  - total    │
                        │  - status   │
                        └──────┬──────┘
                               │
                               │ N:1
                               ▼
                        ┌─────────────┐
                        │   Product   │
                        └─────────────┘

┌─────────────┐
│   Payment   │
│  - method   │
│  - amount   │
│  - reference│
│  - status   │
└──────┬──────┘
       │ N:1
       ▼
┌─────────────┐
│    User     │
└─────────────┘
```

### Core Data Models

#### User (Django built-in)
- username, email, password (hashed)
- first_name, last_name
- is_active, is_staff, is_superuser
- date_joined, last_login

#### Profile
- user (OneToOne → User)
- bio (TextField)
- location (CharField)
- phone_number (CharField with Zambian validation)
- profile_picture (ImageField)
- role (CharField: client/admin)

#### Category
- name (CharField, unique)
- description (TextField)
- created_by (ForeignKey → User)
- created_at, updated_at (DateTimeField)

#### Product
- name (CharField)
- description (TextField)
- price (DecimalField, min 0.01)
- seller (ForeignKey → User)
- category (ForeignKey → Category)
- image (ImageField)
- stock (PositiveIntegerField)
- status (CharField: active/inactive/sold/draft)
- approval_status (CharField: pending/approved/rejected)
- approved_by (ForeignKey → User, nullable)
- approved_at (DateTimeField, nullable)
- created_at, updated_at (DateTimeField)

**Indexes**: 
- (seller, status)
- (created_at)

**Methods**:
- `is_in_stock()`: Check availability
- `is_available_for_customers()`: Check if approved and active
- `reduce_stock(quantity)`: Decrease inventory
- `increase_stock(quantity)`: Increase inventory
- `mark_as_sold()`: Set status to sold

#### Cart
- user (ForeignKey → User)
- product (ForeignKey → Product)
- quantity (PositiveIntegerField, min 1)
- added_at (DateTimeField)

**Unique Together**: (user, product)

**Methods**:
- `get_total_price()`: Calculate item total

#### Checkout
- user (ForeignKey → User)
- location (CharField: inside/outside campus)
- room_number (CharField, optional)
- phone_number (CharField with validation)
- gps_location (CharField: lat,lng format)
- payment_method (CharField: cash/delivery/mtn/airtel)
- delivery_fee (DecimalField, min 0.00)
- transaction_id (CharField, optional)
- payment_status (CharField: pending/completed/failed)
- created_at, updated_at (DateTimeField)

**Methods**:
- `get_total_cost()`: Calculate total including delivery

#### Order
- user (ForeignKey → User)
- product (ForeignKey → Product)
- quantity (PositiveIntegerField, min 1)
- total_price (DecimalField, min 0.01)
- status (CharField: pending/processing/shipped/delivered/cancelled)
- checkout (ForeignKey → Checkout, nullable)
- created_at, updated_at (DateTimeField)

**Methods**:
- `calculate_total()`: Compute order total
- `save()`: Override to handle stock reduction

#### Review
- product (ForeignKey → Product)
- user (ForeignKey → User)
- rating (PositiveIntegerField: 1-5)
- title (CharField)
- comment (TextField)
- is_verified_purchase (BooleanField)
- created_at, updated_at (DateTimeField)

**Unique Together**: (product, user)

**Indexes**:
- (product, rating)
- (created_at)

#### Payment
- user (ForeignKey → User)
- method (CharField: airtel/mtn/stripe)
- amount (DecimalField)
- reference (CharField, unique)
- status (CharField: pending/completed/failed)
- created_at (DateTimeField)

## Error Handling

### Validation Errors

1. **Product Stock Validation**
   - Prevent adding out-of-stock items to cart
   - Validate sufficient stock before order creation
   - Raise `ValueError` with descriptive message

2. **Phone Number Validation**
   - Zambian format: +260XXXXXXXXX
   - Regex validation in model and form layers
   - User-friendly error messages

3. **Price Validation**
   - Minimum price: ZMW 0.01
   - `MinValueValidator` on DecimalField
   - Form-level validation

4. **GPS Location Validation**
   - Required field for checkout
   - Format: "latitude,longitude"
   - JavaScript validation before form submission

### Payment Errors

1. **Payment Processing Failures**
   - Catch API exceptions from payment providers
   - Set payment status to "failed"
   - Display user-friendly error message
   - Log detailed error for debugging

2. **Transaction Timeout**
   - Set reasonable timeout for API calls
   - Implement retry logic for transient failures
   - Notify user of pending status

3. **Webhook Validation**
   - Verify webhook signatures
   - Validate payment reference exists
   - Handle duplicate webhook calls

### Database Errors

1. **Concurrent Stock Updates**
   - Use database transactions (`@transaction.atomic`)
   - Lock rows during stock modification
   - Handle race conditions gracefully

2. **Unique Constraint Violations**
   - Catch `IntegrityError` for duplicate entries
   - Display appropriate error messages
   - Suggest corrective actions

### User Experience Errors

1. **Form Validation**
   - Client-side validation with JavaScript
   - Server-side validation in Django forms
   - Display field-specific error messages
   - Preserve user input on validation failure

2. **404 Errors**
   - Custom 404 page with navigation
   - Suggest similar products
   - Search functionality

3. **Permission Errors**
   - Check user permissions before actions
   - Redirect to login for unauthenticated users
   - Display "Access Denied" for unauthorized actions

## Testing Strategy

### Unit Testing

**Models Testing**:
- Test model creation and validation
- Test custom model methods (e.g., `reduce_stock()`, `calculate_total()`)
- Test model constraints (unique_together, validators)
- Test model relationships (ForeignKey, OneToOne)

**Forms Testing**:
- Test form validation rules
- Test custom validators (phone numbers, prices)
- Test form field requirements
- Test form error messages

**Utilities Testing**:
- Test payment integration functions
- Test delivery fee calculation
- Test phone number formatting

### Integration Testing

**Cart Workflow**:
- Add product to cart
- Update cart quantities
- Remove items from cart
- Cart persistence for logged-in users
- Cart merging on login

**Checkout Workflow**:
- Complete checkout form
- GPS location selection
- Delivery fee calculation
- Payment method selection
- Order creation
- Stock reduction
- Email confirmation

**Order Management**:
- Order status updates
- Order history retrieval
- Order cancellation
- Refund processing

**Review System**:
- Submit product review
- Verify purchase requirement
- Calculate average ratings
- Display reviews on product page

### End-to-End Testing

**User Registration and Login**:
1. Register new account
2. Verify email (if implemented)
3. Login with credentials
4. Access protected pages
5. Logout

**Complete Purchase Flow**:
1. Browse products
2. Add items to cart
3. Proceed to checkout
4. Enter delivery details
5. Select GPS location on map
6. Choose payment method
7. Complete payment
8. Receive order confirmation
9. Track order status

**Admin Workflows**:
1. Login as admin
2. Approve pending products
3. Update order status
4. View sales reports
5. Manage categories
6. Moderate reviews

### Performance Testing

**Load Testing**:
- Simulate concurrent users
- Test database query performance
- Monitor response times
- Identify bottlenecks

**Database Optimization**:
- Test query efficiency with indexes
- Optimize N+1 query problems
- Use `select_related()` and `prefetch_related()`
- Monitor slow queries

### Security Testing

**Authentication Testing**:
- Test password hashing
- Test session management
- Test CSRF protection
- Test SQL injection prevention

**Authorization Testing**:
- Test role-based access control
- Test object-level permissions
- Test admin-only actions
- Test seller-specific product access

**Payment Security**:
- Test secure payment data handling
- Verify no sensitive data in logs
- Test webhook signature validation
- Test transaction idempotency

## Deployment Considerations

### Production Checklist

1. **Security**:
   - Set `DEBUG = False`
   - Use environment variables for secrets
   - Configure `ALLOWED_HOSTS`
   - Enable HTTPS
   - Set secure cookie flags

2. **Database**:
   - Migrate to PostgreSQL
   - Configure database backups
   - Set up connection pooling
   - Optimize database indexes

3. **Static Files**:
   - Configure static file serving (WhiteNoise or CDN)
   - Run `collectstatic`
   - Enable gzip compression
   - Set cache headers

4. **Media Files**:
   - Configure cloud storage (AWS S3, Cloudinary)
   - Set up image optimization
   - Configure backup strategy

5. **Performance**:
   - Enable caching (Redis/Memcached)
   - Configure database query optimization
   - Set up CDN for static assets
   - Enable gzip compression

6. **Monitoring**:
   - Set up error tracking (Sentry)
   - Configure logging
   - Monitor server resources
   - Set up uptime monitoring

7. **Email**:
   - Configure production email backend
   - Set up transactional email service
   - Configure email templates

8. **Payment**:
   - Use production API keys
   - Configure webhook endpoints
   - Test payment flows in production
   - Set up payment monitoring

### Scalability Considerations

1. **Horizontal Scaling**:
   - Stateless application design
   - Session storage in database/Redis
   - Load balancer configuration

2. **Database Scaling**:
   - Read replicas for reporting
   - Database connection pooling
   - Query optimization
   - Caching frequently accessed data

3. **Asynchronous Processing**:
   - Use Celery for background tasks
   - Email sending
   - Payment processing
   - Report generation

4. **Caching Strategy**:
   - Cache product listings
   - Cache category navigation
   - Cache user sessions
   - Invalidate cache on updates
